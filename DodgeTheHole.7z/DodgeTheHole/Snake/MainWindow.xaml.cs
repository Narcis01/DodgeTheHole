﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Windows.Threading;

namespace Snake
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer gameTimer = new DispatcherTimer();
        private bool goUp, goDown, goLeft, goRight;
        int speed = 10;
        int playerPoints = 0;
        public MainWindow()
        {
            InitializeComponent();

            myCanvas.Focus();

            gameTimer.Tick += GameAction;
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            gameTimer.Start();

        }
        
        private void GameAction(object sender, EventArgs e)
        {
            if (goUp == true && Canvas.GetTop(head) > 5)
            {
                Canvas.SetTop(head, Canvas.GetTop(head) - speed);
            }
            if (goDown == true && Canvas.GetTop(head) + (head.Height+50) < Application.Current.MainWindow.Height)
            {
                Canvas.SetTop(head, Canvas.GetTop(head) + speed);
            }
            if(goLeft == true && Canvas.GetLeft(head) >5)
            {
                Canvas.SetLeft(head, Canvas.GetLeft(head) - speed);
            }

            if(goRight == true && Canvas.GetLeft(head) + (head.Width+50)<Application.Current.MainWindow.Width)
            {
                Canvas.SetLeft(head, Canvas.GetLeft(head) + speed);
            }

 

            Rect headHitBox = new Rect(Canvas.GetLeft(head), Canvas.GetTop(head), head.Width, head.Height);
            Rect foodHitBox = new Rect(Canvas.GetLeft(food), Canvas.GetTop(food), food.Width, food.Height);


            foreach (var x in myCanvas.Children.OfType<Rectangle>())
            {
                if ((string)x.Tag == "point")
                {
                    Rect pointHitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (pointHitBox.IntersectsWith(headHitBox))
                    {
                        speed = 0;
                        Title = "Game over!! Your points: "+playerPoints;
                    }
                }
            }

            

            if (headHitBox.IntersectsWith(foodHitBox))
            {
                Random rd = new Random();
                int top = rd.Next(0, 400);
                int left = rd.Next(0, 400);

                Canvas.SetLeft(food, left);
                Canvas.SetTop(food, top);

                Rectangle rec = new Rectangle();
                rec.Width = 20;
                rec.Height = 20;
                
                rec.Tag = "point";

                top = rd.Next(0, 400);
                left = rd.Next(0, 400);

                Canvas.SetLeft(rec, left);
                Canvas.SetTop(rec, top);


                rec.Fill = Brushes.Black;

                myCanvas.Children.Add(rec);
                playerPoints++;
                Title = "DodgeTheHole! Your points: "+playerPoints;
                speed++;
                

            }

            

        }

        private void MyCanvas_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Up || e.Key == Key.W)
                goUp = false;
            if (e.Key == Key.S || e.Key == Key.Down)
                goDown = false;
            if (e.Key == Key.Left || e.Key == Key.A)
                goLeft = false;
            if (e.Key == Key.Right || e.Key == Key.D)
                goRight = false;
        }

        private void MyCanvas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Up || e.Key == Key.W)
                goUp = true;
            if (e.Key == Key.S || e.Key == Key.Down)
                goDown = true;
            if (e.Key == Key.Left || e.Key == Key.A)
                goLeft = true;
            if (e.Key == Key.Right || e.Key == Key.D)
                goRight = true;
        }
    }
}
